package com.example.yay

interface CustomDialogInterface {
    fun onCheckButtonClicked()
}