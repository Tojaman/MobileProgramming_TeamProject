package com.example.yay

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.yay.databinding.ActivityMypageReservationBinding

class Mypage_reservation : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_reservation)

        title = "나의 예약 현황"

        val binding = ActivityMypageReservationBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 버튼 클릭 이벤트 처리
        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.MainReservationbtn.setOnClickListener {
            val intent = Intent(this, SpaceActivity::class.java)
            startActivity(intent)
        }

        binding.MainProgrambtn.setOnClickListener {
            val intent = Intent(this, ProgramActivity::class.java)
            startActivity(intent)
        }

        binding.MainMypagebtn.setOnClickListener {
            val intent = Intent(this, Mypage_main::class.java)
            startActivity(intent)
        }
    }
}