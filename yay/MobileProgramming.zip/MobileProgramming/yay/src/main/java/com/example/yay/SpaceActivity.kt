package com.example.yay

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.yay.databinding.ActivitySpaceBinding

// CustomDialogInterface : 현준님이 만든 인터페이스
// -> onCheckButtonClicked 함수 있어서 이거 재정의해서 사용할 수 있음
class SpaceActivity : AppCompatActivity(), CustomDialogInterface{
    private lateinit var binding : ActivitySpaceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        val customDialog = SpaceInformationActivity(this,this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_space)

        // Space 바인딩 객체 생성
        binding = ActivitySpaceBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 대관 리스트에 있는 신청 버튼 누르면 안내 메시지 팝업 띄우기
        val buttons = listOf(binding.button1, binding.button2, binding.button3, binding.button4)

        for (button in buttons) {
            button.setOnClickListener {
                customDialog.show() // 대관 안내 팝업창 show()
                onCheckButtonClicked() // "추가" 메시지를 띄움
            }
        }

        // 버튼 클릭 이벤트 처리
        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finishAffinity()
        }

        binding.MainReservationbtn.setOnClickListener {
            val intent = Intent(this, SpaceActivity::class.java)
            startActivity(intent)
        }

        binding.MainProgrambtn.setOnClickListener {
            val intent = Intent(this, ProgramActivity::class.java)
            startActivity(intent)
        }

        binding.MainMypagebtn.setOnClickListener {
            val intent = Intent(this, Mypage_main::class.java)
            startActivity(intent)
        }
    }

    override fun onCheckButtonClicked() {
        Toast.makeText(this, "추가", Toast.LENGTH_SHORT).show()
    }
}