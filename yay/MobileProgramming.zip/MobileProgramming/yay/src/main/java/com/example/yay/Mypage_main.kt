package com.example.yay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.example.yay.databinding.ActivityMypageMainBinding

class Mypage_main : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_main)
        title = "마이페이지"

        val binding = ActivityMypageMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 계정 정보 변경 버튼 인텐트
        binding.MypageAccountBtn.setOnClickListener(){
            val intent = Intent(applicationContext, Mypage_account::class.java)
            startActivity(intent)
        }

        // 예약현황 버튼 인텐트
        binding.MypageReservationBtn.setOnClickListener(){
            val intent = Intent(applicationContext, Mypage_reservation::class.java)
            startActivity(intent)
        }

        // 로그아웃 버튼 인텐트
        binding.MypageLogoutBtn.setOnClickListener {
            // 로그아웃이 되고나서 이전페이지로 돌아가야함.
            finish()
        }
        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.MainReservationbtn.setOnClickListener {
            val intent = Intent(this, SpaceActivity::class.java)
            startActivity(intent)
        }

        binding.MainProgrambtn.setOnClickListener {
            val intent = Intent(this, ProgramActivity::class.java)
            startActivity(intent)
        }

        binding.MainMypagebtn.setOnClickListener {
            val intent = Intent(this, Mypage_main::class.java)
            startActivity(intent)
        }
    }
}