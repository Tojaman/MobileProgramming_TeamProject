package com.example.yay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.example.yay.databinding.ActivityMypageAccountBinding

class Mypage_account : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_account)
        title = "계정정보"

        val binding = ActivityMypageAccountBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 이름, 주소, 아이디, 전화번호, 이메일 데이터베이스에서 불러오는 코드 필요.

        // 비밀번호 변경 버튼 인텐트
        binding.MypageChangepwdBtn.setOnClickListener(){
            val intent = Intent(applicationContext, Mypage_changepwd::class.java)
            startActivity(intent)
        }

        binding.MypageModifyinformBtn.setOnClickListener(){
            // 정보 수정을 완료하는 코드 필요.
            finish()
        }

        binding.MypageCancelformBtn.setOnClickListener(){
            // 정보 수정 안했으니까 그냥 돌아가면 된다.
            finish()
        }
        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.MainReservationbtn.setOnClickListener {
            val intent = Intent(this, SpaceActivity::class.java)
            startActivity(intent)
        }

        binding.MainProgrambtn.setOnClickListener {
            val intent = Intent(this, ProgramActivity::class.java)
            startActivity(intent)
        }

        binding.MainMypagebtn.setOnClickListener {
            val intent = Intent(this, Mypage_main::class.java)
            startActivity(intent)
        }
    }
}