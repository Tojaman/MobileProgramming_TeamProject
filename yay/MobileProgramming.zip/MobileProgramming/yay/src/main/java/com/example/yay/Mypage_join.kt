package com.example.yay

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Mypage_join : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_join)
    }
}