package com.example.yay

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import com.example.yay.databinding.ActivityMypageNotifyIdBinding

class Mypage_notifyID(context: Context, Interface: CustomDialogInterface) : Dialog(context) {

    // 액티비티에서 인터페이스를 받아옴
    private var customDialogInterface: CustomDialogInterface = Interface

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_notify_id)

        val binding = ActivityMypageNotifyIdBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 배경을 투명하게함
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        // 추가 버튼 클릭 시 onAddButtonClicked 호출 후 종료
        binding.MypageChecknotifyIDBtn.setOnClickListener {
            customDialogInterface.onCheckButtonClicked()
            dismiss()
        }

        // 취소 버튼 클릭 시 onCancelButtonClicked 호출 후 종료
//        cancelButton.setOnClickListener {
//            customDialogInterface.onCancelButtonClicked()
//            dismiss()}
    }
}

//class Mypage_notifyID : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_mypage_notify_id)
//        // 탑에 있는 기본 이미지 여기에도 넣어야하나..?
//        title = "ID 알려주는 페이지지렁"
//
//        val binding = ActivityMypageNotifyIdBinding.inflate(layoutInflater)
//        val view = binding.root
//        setContentView(view)
//
//        // 해당 회원의 ID를 띄워주는 코드 필요.
//
//        // 아이디 확인했다는 의미의 버튼 인텐트
//        binding.MypageChecknotifyIDBtn.setOnClickListener(){
//            val intent = Intent(applicationContext, Mypage_login::class.java)
//            startActivity(intent)
//        }
//    }
//}