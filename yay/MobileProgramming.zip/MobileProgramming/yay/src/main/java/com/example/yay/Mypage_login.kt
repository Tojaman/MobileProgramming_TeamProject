package com.example.yay

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.yay.databinding.ActivityMypageLoginBinding

class Mypage_login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_login)
        title = "로그인"

        val binding = ActivityMypageLoginBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 비밀번호 찾기 버튼 인텐트
        binding.MypageFindpwdBtn.setOnClickListener(){
            val intent = Intent(applicationContext, Mypage_find_pwd::class.java)
            startActivity(intent)
        }

        // ID 찾기 버튼 인텐트
        binding.MypageFindIDBtn.setOnClickListener(){
            val intent = Intent(applicationContext, Mypage_findID::class.java)
            startActivity(intent)
        }

        // 로그인 버튼 인텐트 로그인 성공과 실패 나누기
        binding.MypageLoginBtn.setOnClickListener(){
            // 로그인되는 코드 추가
            // 로그인 됐는지 안됐는지 확인하는 코드 if ~ else로 추가

            // 로그인 성공했을 때
            // 토스트메세지로 안에 아이디와 패스워드가 일치 했을 때 로그인 완료하는 내용 넣기
            Toast.makeText(this,"로그인이 성공하였습니다!",Toast.LENGTH_SHORT).show()
            finish()

            // 로그인 실패했을 때
            // Toast.makeText(this,"로그인이 실패하였습니다. 다시 작성해주세요.",Toast.LENGTH_SHORT)
            // 지금까지 editText에 작성했던거 다 지워지는 정도?
            //
        }

        binding.MypageJoinBtn.setOnClickListener(){
            // 정보 수정 안했으니까 그냥 돌아가면 된다.
            val intent = Intent(applicationContext, Mypage_join::class.java)
            startActivity(intent)
        }
    }
}