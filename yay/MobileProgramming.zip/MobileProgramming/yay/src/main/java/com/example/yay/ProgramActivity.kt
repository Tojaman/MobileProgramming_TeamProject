package com.example.yay

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.yay.databinding.ActivityProgramBinding

class ProgramActivity : AppCompatActivity(), CustomDialogInterface{

    private lateinit var binding : ActivityProgramBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        val customDialog = ProgramInfomationActitivty(this,this)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_program)

        binding = ActivityProgramBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.button9.setOnClickListener{
            customDialog.show()
            onCheckButtonClicked()
        }

        // 버튼 클릭 이벤트 처리
        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.MainReservationbtn.setOnClickListener {
            val intent = Intent(this, SpaceActivity::class.java)
            startActivity(intent)
        }

        binding.MainProgrambtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.MainMypagebtn.setOnClickListener {
            val intent = Intent(this, Mypage_main::class.java)
            startActivity(intent)
        }
    }

    override fun onCheckButtonClicked() {
        Toast.makeText(this, "추가", Toast.LENGTH_SHORT).show()
    }
}