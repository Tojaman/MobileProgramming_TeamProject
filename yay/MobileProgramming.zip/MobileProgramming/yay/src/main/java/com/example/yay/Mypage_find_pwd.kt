package com.example.yay

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.yay.databinding.ActivityMypageFindPwdBinding

class Mypage_find_pwd : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_find_pwd)

        val binding = ActivityMypageFindPwdBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.MainReservationbtn.setOnClickListener {
            val intent = Intent(this, SpaceActivity::class.java)
            startActivity(intent)
        }

        binding.MainProgrambtn.setOnClickListener {
            val intent = Intent(this, ProgramActivity::class.java)
            startActivity(intent)
        }

        binding.MainMypagebtn.setOnClickListener {
            val intent = Intent(this, Mypage_main::class.java)
            startActivity(intent)
        }

        // 비밀번호 불러주는거 문자로 보내주면 죠을 듯..?

        // edit적고 확인해주는 의미의 버튼 인텐트
        binding.MypageCheckphoneBtn.setOnClickListener(){
            // edit 내용의 회원이 존재하지 않을 때.
            Toast.makeText(this,"정보가 일치하는 회원이 존재하지 않습니다. 다시 확인해주세요.",Toast.LENGTH_SHORT)
            // 이거는 내용 안지워주고 그냥 그대로 고치게끔?

            // edit 내용의 회원이 존재할 때.
            Toast.makeText(this,"임시 비밀번호가 발송되었습니다!",Toast.LENGTH_SHORT)
            val intent = Intent(applicationContext, Mypage_login::class.java)
            startActivity(intent)
        }
    }
}