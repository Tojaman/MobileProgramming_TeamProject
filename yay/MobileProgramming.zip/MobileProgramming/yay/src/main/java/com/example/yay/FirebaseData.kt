package com.example.yay

data class FirebaseData(
    val sampleName: String,
    val sampleNumber: Int,
    val sampleBoolean: Boolean
)
