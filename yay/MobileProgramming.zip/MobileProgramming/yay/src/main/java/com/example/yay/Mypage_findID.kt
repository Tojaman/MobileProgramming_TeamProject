package com.example.yay

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.example.yay.databinding.ActivityMypageFindIdBinding



class Mypage_findID : AppCompatActivity(), CustomDialogInterface {
    override fun onCheckButtonClicked() {
        Toast.makeText(this, "추가", Toast.LENGTH_SHORT).show()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mypage_find_id)
        title = "아이디 찾기"

        val customDialog = Mypage_notifyID(this,this)
        val binding = ActivityMypageFindIdBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.MypageCheckBtn.setOnClickListener(){
            // 정보 일치하는 회원이 있는지 찾아보는 코드 필요 if~else 문으로 짤듯!

            // edit에 적힌 정보의 회원이 없을 때
//            Toast.makeText(this,"일치하는 정보가 없습니다. 다시 작성해주세요.",Toast.LENGTH_SHORT)

            // edit에 적힌 정보의 회원이 존재할 때
            // 데이터베이스에서 ID 찾아오기 코드 필요.
            customDialog.show()
            onCheckButtonClicked()
        }
    }
}