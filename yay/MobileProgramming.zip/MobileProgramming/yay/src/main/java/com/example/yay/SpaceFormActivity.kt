package com.example.yay

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.yay.databinding.ActivitySpaceFormBinding

class SpaceFormActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_space_form)

/*        val datePicker = findViewById<DatePicker>(R.id.datePicker)
        val timePicker = findViewById<TimePicker>(R.id.timePicker)*/

        val binding = ActivitySpaceFormBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)


        // 날자 및 시간 선택 버튼 누르면 시간 선택, 날짜 선택 위젯 나옴
/*        binding.SelectDateBtn.setOnClickListener {
            val datePickerDialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
                // 선택된 날짜 처리 로직
                val selectedDate = "${year}년 ${month + 1}월 ${dayOfMonth}일"
                binding.SpaceTime.text = selectedDate

                // TimePickerDialog 생성
                val timePickerDialog = TimePickerDialog(
                    this, { _, hourOfDay, minute ->
                        val selectedTime = "${hourOfDay}시 ${minute}분"
                        binding.SpaceTime.text = "${binding.SpaceTime.text} $selectedTime"
                        // 여기에서 선택된 날짜와 시간을 처리할 수 있습니다.
                    },
                    0, 0, false
                ) // 초기 선택 시간 (0시 0분), 24시간 형식 사용 여부(false로 설정하면 AM/PM 형식 사용)

                timePickerDialog.show()
            }, 2023, 0, 1) // 초기 선택 날짜 (2023년 1월 1일)

            datePickerDialog.show()
        }*/
        binding.SelectDateBtn.setOnClickListener {
            val datePickerDialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
                // 선택된 날짜 처리 로직
                val selectedDate = "${year}년 ${month + 1}월 ${dayOfMonth}일"
                binding.SpaceTime.text = selectedDate

                // TimePickerDialog 대신 Spinner 사용
                val timeValues = (10..22).map { "${it}시" }
                val minuteValues = arrayOf("0분", "15분", "30분", "45분")

                // 시 선택
                val timeSpinner = Spinner(this)
                val timeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, timeValues)
                timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                timeSpinner.adapter = timeAdapter

                // 분 선택
                val minuteSpinner = Spinner(this)
                // minuteValues 배열 데이터를 android.R.layout.simple_spinner_item 레이아웃 형식으로 저장한다.
                val minuteAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, minuteValues)
                // minuteAdapter를 드롭다운 형식 view로 바꿈
                minuteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                minuteSpinner.adapter = minuteAdapter

                val timePickerLayout = LinearLayout(this)
                timePickerLayout.orientation = LinearLayout.HORIZONTAL
                timePickerLayout.addView(timeSpinner)
                timePickerLayout.addView(minuteSpinner)

                AlertDialog.Builder(this)
                    .setTitle("시간 선택")
                    .setView(timePickerLayout)
                    .setPositiveButton("확인") { _, _ ->
                        val selectedTime = "${timeSpinner.selectedItem} ${minuteSpinner.selectedItem}"
                        binding.SpaceTime.append(" $selectedTime")
                        // 여기에서 선택된 날짜와 시간을 처리할 수 있습니다.
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }, 2023, 0, 1) // 초기 선택 날짜 (2023년 1월 1일)

            datePickerDialog.show()
        }



        // 신청하기 버튼을 누르면 예약 완료 페이지로 넘어감
        binding.SpaceFormSubmitBtn.setOnClickListener {
            val intent = Intent(this, SpaceReserationActivity::class.java)
            startActivity(intent)
        }


        /*val intent = Intent(this, SpaceReserationActivity::class.java)
        startActivity(intent)*/


        // 버튼 클릭 이벤트 처리
        binding.MainHomebtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            //
            //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finishAffinity() // 현재 액티비티와 그 위에 쌓인 모든 액티비티 종료료        }

            binding.MainReservationbtn.setOnClickListener {
                val intent = Intent(this, SpaceActivity::class.java)
                startActivity(intent)
            }

            binding.MainProgrambtn.setOnClickListener {
                val intent = Intent(this, ProgramActivity::class.java)
                startActivity(intent)
            }

            binding.MainMypagebtn.setOnClickListener {
                val intent = Intent(this, Mypage_main::class.java)
                startActivity(intent)
            }


        }

    }
}