package com.example.project10_2

import android.os.Bundle
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.project10_2.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = "투표 결과"

        var intent = intent
        var voteResult = intent.getIntArrayExtra("VoteCount")
        var imageName = intent.getStringArrayExtra("ImageName")

        var tv = arrayOfNulls<TextView>(imageName!!.size)
        var rbar = arrayOfNulls<RatingBar>(imageName.size)
        var max:Int = -1

        // 그림 아이디별로 배열에 넣어줌
        val imageFileId = arrayOf(R.drawable.pic1, R.drawable.pic2, R.drawable.pic3, R.drawable.pic4,
            R.drawable.pic5, R.drawable.pic6, R.drawable.pic7, R.drawable.pic8, R.drawable.pic9)
        // 각 그림마다 이름 알려주는 텍스트 배열로 정의
        var tvID = arrayOf(R.id.tv1, R.id.tv2, R.id.tv3, R.id.tv4, R.id.tv5, R.id.tv6, R.id.tv7, R.id.tv8, R.id.tv9)
        // 각 그림의 별점 배열로 정의
        var rbarID = arrayOf(R.id.rbar1, R.id.rbar2, R.id.rbar3, R.id.rbar4, R.id.rbar5, R.id.rbar6, R.id.rbar7, R.id.rbar8, R.id.rbar9)

        // 각 배열마다 tv[i]에는 각 아이디에 해당하는 TextView 객체를, rbar[i]에는 각 아이디에 해당하는 RatingBar 객체를 저장.
        for (i in voteResult!!.indices) {
            tv[i] = findViewById<TextView>(tvID[i])
            rbar[i] = findViewById<RatingBar>(rbarID[i])
        }

        // tv[i]에는 각 그림마다의 그림 이름을 넣어줌, rbar[i]에 각 그림마다의 평점을 toFloat() 해줌으로써 별점을 표현해줌
        for (i in voteResult.indices) {
            tv[i]!!.setText(imageName!![i])
            rbar[i]!!.setRating(voteResult[i].toFloat())
        }

        // 돌아가기 버튼을 누르면 다시 MainActivity로 돌아감.
        var btnReturn = findViewById<Button>(R.id.btnReturn)
        btnReturn.setOnClickListener {
            finish()
        }

        // 최대 득표 수를 찾기
        for (i in voteResult.indices) {
            if (max < voteResult[i]) {
                max = voteResult[i]
            }

            // 최대 득표 수를 가진 그림의 이미지와 이름을 띄워주기
            if(voteResult[i] == max){
                if(i == 0) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 1) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 2) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 3) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 4) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 5) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 6) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 7) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 8) binding.imageField.setImageResource(imageFileId[i])
                else if(i == 9) binding.imageField.setImageResource(imageFileId[i])
                binding.maxTextView.setText(imageName[i])
            }
        }
    }
}