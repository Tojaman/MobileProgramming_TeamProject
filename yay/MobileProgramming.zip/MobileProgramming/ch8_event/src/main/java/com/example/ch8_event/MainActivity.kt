package com.example.ch8_event

import android.os.Bundle
import android.view.KeyEvent
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ch8_event.databinding.ActivityMainBinding
import java.util.*
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {
    // 뒤로가기 버튼을 누른 시각을 저장하는 속성
    private lateinit var binding: ActivityMainBinding
    private var time = 0
    private var timerTask: Timer? = null
    private var isRunning = false
    private var lap = 1
    private var initTime: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val startFab = binding.startFab
        val resetFab = binding.resetFab
        val lapButton = binding.lapButton
        val secTextView = binding.secTextView
        val milliTextView = binding.milliTextView
        startFab.bringToFront();

        fun start(){
            startFab.setImageResource(R.drawable.baseline_pause_24)

            timerTask = timer(period = 10){
                time++
                val sec = time / 100
                val milli = time % 100
                runOnUiThread{
                    secTextView.text = "$sec"
                    milliTextView.text = "$milli"
                }
            }
        }

        fun pause(){
            startFab.setImageResource(R.drawable.baseline_play_arrow_24)
            timerTask?.cancel()
        }

        fun reset(){
            timerTask?.cancel()

            time = 0
            isRunning = false
            startFab.setImageResource(R.drawable.baseline_pause_24)
            secTextView.text = "0"
            milliTextView.text = "00"

            binding.lapLayout.removeAllViews()
            lap = 1
        }

        fun recordLapTime(){
            val lapTime = this.time
            var textView = TextView(this)
            textView.text = "$lap LAB : ${lapTime / 100} . ${lapTime % 100}"

            binding.lapLayout.addView(textView, 0)
            if(lap > 5){
                binding.lapLayout.removeViewAt(0)
            }
            lap++
        }

        timer(period = 1000){
            runOnUiThread{

            }
        }

        startFab.setOnClickListener {
            isRunning = !isRunning
            if(isRunning) {
                start()
            } else {
                pause()
            }
        }

        lapButton.setOnClickListener{
            recordLapTime()
        }

        resetFab.setOnClickListener{
            reset()
            startFab.bringToFront();
        }
    }
    // 뒤로가기 버튼 이벤트 핸들러
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // 뒤로가기 버튼을 눌렀을 때 처리
        if (keyCode === KeyEvent.KEYCODE_BACK) {
            // 뒤로가기 버튼을 처음 눌렀거나 누른 지 3초가 지났을 때 처리
            if (System.currentTimeMillis() - initTime > 3000) {
                Toast.makeText(this, "종료하려면 한 번 더 누르세요!!",
                    Toast.LENGTH_SHORT).show()
                initTime = System.currentTimeMillis()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

private fun Button.setImageRecource(icPauseBlack24dp: Any) {

}
