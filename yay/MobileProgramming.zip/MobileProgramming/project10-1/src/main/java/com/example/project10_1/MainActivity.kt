package com.example.project10_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.project10_1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var page:Int = 1
        title = "10-2 실습"

        // 각 radio 버튼을 눌렀을때 페이지 숫자를 출력해줌.
        binding.radioGroup.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.secondButton -> {
                    // second 페이지로 변환됨.
                    page = 2
                }
                R.id.thirdButton -> {
                    // third 페이지로 변환됨.
                    page = 3
                }
            }
        }

        // 새 화면 열기 버튼을 눌렀을 때 실행될 코드
        binding.btnNewActivity.setOnClickListener(){
            if (page == 2){
                var intent = Intent(applicationContext, second_activity::class.java)
                startActivity(intent)
            }
            else if(page == 3){
                var intent = Intent(applicationContext, third_activity::class.java)
                startActivity(intent)
            }
            else {
                Toast.makeText(applicationContext,"옵션을 선택해주세요!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}