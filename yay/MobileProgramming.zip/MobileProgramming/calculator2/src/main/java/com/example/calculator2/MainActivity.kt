package com.example.calculator2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.calculator2.R


class MainActivity : AppCompatActivity() {
    lateinit var edit1: EditText
    lateinit var edit2: EditText
    lateinit var btnAdd: Button
    lateinit var btnSub: Button
    lateinit var btnMul: Button
    lateinit var btnDiv: Button
    lateinit var textResult: TextView
    lateinit var num1: String
    lateinit var num2: String
    lateinit var btnAll: Button
    lateinit var btnBack: Button

    var result: Int? = null
    var numButtons = arrayOfNulls<Button>(10)
    var numBtnIDs = arrayOf(
        R.id.BtnNum0,
        R.id.BtnNum1,
        R.id.BtnNum2,
        R.id.BtnNum3,
        R.id.BtnNum4,
        R.id.BtnNum5,
        R.id.BtnNum6,
        R.id.BtnNum7,
        R.id.BtnNum8,
        R.id.BtnNum9
    )
    var i = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "계산기"
        edit1 = findViewById<View>(R.id.edit1) as EditText
        edit2 = findViewById<View>(R.id.edit2) as EditText
        btnAdd = findViewById<View>(R.id.btnAdd) as Button
        btnSub = findViewById<View>(R.id.btnSub) as Button
        btnMul = findViewById<View>(R.id.btnMul) as Button
        btnDiv = findViewById<View>(R.id.btnDiv) as Button
        textResult = findViewById<View>(R.id.textResult) as TextView
        btnAll = findViewById<Button>(R.id.btnAll) as Button
        btnBack = findViewById<Button>(R.id.btnBack) as Button

        btnAdd!!.setOnTouchListener { arg0, arg1 ->
            num1 = edit1!!.text.toString()
            num2 = edit2!!.text.toString()
            result = num1!!.toInt() + num2!!.toInt()
            textResult!!.text = result.toString()
            false
        }
        btnSub!!.setOnTouchListener { arg0, arg1 ->
            num1 = edit1!!.text.toString()
            num2 = edit2!!.text.toString()
            result = num1!!.toInt() - num2!!.toInt()
            textResult!!.text = result.toString()
            false
        }
        btnMul!!.setOnTouchListener { arg0, arg1 ->
            num1 = edit1!!.text.toString()
            num2 = edit2!!.text.toString()
            result = num1!!.toInt() * num2!!.toInt()
            textResult!!.text = result.toString()
            false
        }
        btnDiv!!.setOnTouchListener { arg0, arg1 ->
            num1 = edit1!!.text.toString()
            num2 = edit2!!.text.toString()
            if(num2!!.toInt() == 0){
                Toast.makeText(this, "피연산자를 입력하세요.", Toast.LENGTH_SHORT).show()
            }else{
                result = num1.toInt() / num2.toInt()
            }
            if(result == 0){
                textResult!!.setText("값이 유효하지 않습니다.")
            }else {
                textResult!!.text = result.toString()
            }
            false
        }

        btnAll.setOnClickListener {
            if(edit1.isFocused == true){
                num1=""
                edit1.setText(num1)
            }else if(edit2.isFocused == true){
                num2=""
                edit2.setText(num2)
            }
        }

        btnBack.setOnClickListener{
            if(edit1.isFocused == true){
                num1 = num1.substring(0, num1.length - 1)
                edit1.setText(num1)
            }else if(edit2.isFocused == true){
                num2 = num2.substring(0, num2.length - 1)
                edit2.setText(num2)
            }
        }

        i = 0
        while (i < numBtnIDs.size) {
            numButtons[i] = findViewById<View>(numBtnIDs[i]) as Button
            i++
        }
        i = 0
        while (i < numBtnIDs.size) {
            val index: Int
            index = i
            numButtons[index]!!.setOnClickListener {
                if (edit1!!.isFocused == true) {
                    num1 = (edit1!!.text.toString()
                            + numButtons[index]!!.text.toString())
                    edit1!!.setText(num1)
                } else if (edit2!!.isFocused == true) {
                    num2 = (edit2!!.text.toString()
                            + numButtons[index]!!.text.toString())
                    edit2!!.setText(num2)
                } else {
                    Toast.makeText(applicationContext, "먼저 에디트텍스트를 선택하세요", Toast.LENGTH_SHORT)
                        .show()
                }
            }
            i++
        }
    }
}