package com.example.ch13_bmicalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.example.ch13_bmicalculator.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 전달 받은 키와 몸무게
        val height = intent.getStringExtra("height")!!.toInt()
        val weight = intent.getStringExtra("weight")!!.toInt()

        // BMI 계산
        val bmi = weight / Math.pow(height / 100.0, 2.0)

        // 결과 표시
        when {
            bmi >= 35 -> findViewById<TextView>(R.id.resultTextView).text = "고도 비만"
            bmi >= 30 -> findViewById<TextView>(R.id.resultTextView).text = "2단계 비만"
            bmi >= 25 -> findViewById<TextView>(R.id.resultTextView).text = "1단계 비만"
            bmi >= 23 -> findViewById<TextView>(R.id.resultTextView).text = "과체중"
            bmi >= 18.5 -> findViewById<TextView>(R.id.resultTextView).text = "정상"
            else -> findViewById<TextView>(R.id.resultTextView).text = "저체중"
        }

        // 이미지 표시
        when {
            bmi >= 23 ->
                binding.imageView.setImageResource(
                    R.drawable.ic_sentiment_very_dissatisfied_black_24dp)
            bmi >= 18.5 ->
                binding.imageView.setImageResource(
                    R.drawable.ic_sentiment_satisfied_black_24dp)
            else ->
                binding.imageView.setImageResource(
                    R.drawable.ic_sentiment_dissatisfied_black_24dp)
        }

        // 토스트 메시지로 BMI 값 표시
        Toast.makeText(this,"$bmi",Toast.LENGTH_SHORT)
    }
}