@file:Suppress("DEPRECATION")

package com.example.ch13_bmicalculator

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.ch13_bmicalculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 이전에 입력한 값을 읽어오기
        loadData()


        binding.resultButton.setOnClickListener {
            // 마지막에 입력한 내용을 저장
            saveData(binding.heightEditText.text.toString().toInt(),
                findViewById<EditText>(R.id.weightEditText).text.toString().toInt())
            var intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("weight",binding.weightEditText.text.toString())
            intent.putExtra("height",binding.heightEditText.text.toString())
            startActivity(intent)
        }
    }

    private fun saveData(height: Int, weight: Int) {
        val pref = PreferenceManager.getDefaultSharedPreferences(this)
        val editor = pref.edit()

        editor.putInt("KEY_HEIGHT", height)
        editor.putInt("KEY_WEIGHT", weight)
        editor.apply()
    }

    private fun loadData() {
        val pref = PreferenceManager.getDefaultSharedPreferences(this)
        val height = pref.getInt("KEY_HEIGHT", 0)
        val weight = pref.getInt("KEY_WEIGHT", 0)

        if (height != 0 && weight != 0) {
            findViewById<EditText>(R.id.heightEditText).setText(height.toString())
            findViewById<EditText>(R.id.weightEditText).setText(weight.toString())
        }
    }
}