package com.example.yay

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProgramAdapter(private val context: Context) : RecyclerView.Adapter<ProgramAdapter.ViewHolder>() {

    // ViewHolder 클래스 정의


    var datas = mutableListOf<FirebaseData>()

    // onCreateViewHolder 메서드 구현
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false)
        return ViewHolder(view)
    }

    // onBindViewHolder 메서드 구현
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(datas[position])
    }

    // getItemCount 메서드 구현
    override fun getItemCount(): Int = datas.size

    // ViewHolder 클래스 정의
    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private val txttitle: TextView = itemView.findViewById(R.id.Program5_Title)
        private val txttime: TextView = itemView.findViewById(R.id.Program5_time)
        private val txtlocation: TextView = itemView.findViewById(R.id.Program5_location)
        private val imgprogram: ImageView = itemView.findViewById(R.id.img_rv_photo)

        fun bind(item: FirebaseData) {
            txttitle.text = item.title
            txttime.text = item.time.toString()
            txtlocation.text = item.location

            // Glide : 이미지뷰를 쉽게 띄우기 위해 쓰는 거라는데 뭔진 잘 모르겠음
            Glide.with(itemView).load(item.program).into(imgprogram)

        }
    }
}
