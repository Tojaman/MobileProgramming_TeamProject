package com.example.yay

data class FirebaseData(
    val program : Int,
    val title: String,
    val time: String,
    val location: String
)
